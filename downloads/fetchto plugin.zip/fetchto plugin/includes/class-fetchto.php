<?php
if (!defined('ABSPATH')) exit;

class Fetchto {

    private $options;

    public function __construct() {
        $this->options = get_option('fetchto_options', []);
        
        add_action('woocommerce_thankyou', [$this, 'send_encrypted_order_to_backend'], 10, 1);
        add_action('woocommerce_admin_order_data_after_shipping_address', [$this, 'add_custom_fields_to_admin_order']);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_and_sync_all_updates'], 10, 1);
        
        add_filter('woocommerce_my_account_my_orders_columns', [$this, 'add_tracking_column_to_orders_list']);
        add_action('woocommerce_my_account_my_orders_column_fetchto-tracking', [$this, 'display_tracking_column_content']);
        add_action('woocommerce_view_order', [$this, 'display_tracking_details_on_view_order_page'], 20);
        
        add_action('rest_api_init', [$this, 'register_callback_endpoint']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function add_admin_menu() {
        add_options_page(
            'Fetchto',
            'Fetchto',
            'manage_options',
            'fetchto',
            [$this, 'settings_page_html']
        );
    }

    public function register_settings() {
        register_setting('fetchto_options_group', 'fetchto_options', [
            'sanitize_callback' => [$this, 'sanitize_options']
        ]);

        add_settings_section(
            'fetchto_settings_section',
            'API Credentials',
            [$this, 'settings_section_callback'],
            'fetchto'
        );

        add_settings_field(
            'seller_id',
            'Seller ID',
            [$this, 'seller_id_field_callback'],
            'fetchto',
            'fetchto_settings_section'
        );

        add_settings_field(
            'secret_key',
            'Secret Key',
            [$this, 'secret_key_field_callback'],
            'fetchto',
            'fetchto_settings_section'
        );

        add_settings_field(
            'hmac_key',
            'HMAC Key',
            [$this, 'hmac_key_field_callback'],
            'fetchto',
            'fetchto_settings_section'
        );

        add_settings_field(
            'api_url',
            'API URL',
            [$this, 'api_url_field_callback'],
            'fetchto',
            'fetchto_settings_section'
        );
    }

    public function sanitize_options($input) {
        $sanitized_input = [];
        if (isset($input['seller_id'])) {
            $sanitized_input['seller_id'] = sanitize_text_field($input['seller_id']);
        }
        if (isset($input['secret_key'])) {
            $sanitized_input['secret_key'] = sanitize_text_field($input['secret_key']);
        }
        if (isset($input['hmac_key'])) {
            $sanitized_input['hmac_key'] = sanitize_text_field($input['hmac_key']);
        }
        if (isset($input['api_url'])) {
            $sanitized_input['api_url'] = esc_url_raw($input['api_url']);
        }
        return $sanitized_input;
    }

    public function settings_section_callback() {
        echo '<p>Enter your API credentials below. These are required to sync orders with the backend.</p>';
    }

    public function seller_id_field_callback() {
        $value = isset($this->options['seller_id']) ? esc_attr($this->options['seller_id']) : '';
        echo '<input type="text" id="seller_id" name="fetchto_options[seller_id]" value="' . $value . '" class="regular-text" />';
    }

    public function secret_key_field_callback() {
        $value = isset($this->options['secret_key']) ? esc_attr($this->options['secret_key']) : '';
        echo '<input type="text" id="secret_key" name="fetchto_options[secret_key]" value="' . $value . '" class="regular-text" />';
    }

    public function hmac_key_field_callback() {
        $value = isset($this->options['hmac_key']) ? esc_attr($this->options['hmac_key']) : '';
        echo '<input type="text" id="hmac_key" name="fetchto_options[hmac_key]" value="' . $value . '" class="regular-text" />';
    }

    public function api_url_field_callback() {
        $value = isset($this->options['api_url']) ? esc_attr($this->options['api_url']) : 'http://localhost:8080/api/orders/';
        echo '<input type="text" id="api_url" name="fetchto_options[api_url]" value="' . $value . '" class="regular-text" />';
    }

    public function settings_page_html() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('fetchto_options_group');
                do_settings_sections('fetchto');
                submit_button('Save Settings');
                ?>
            </form>
        </div>
        <?php
    }

    public function send_encrypted_order_to_backend($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $api_url = !empty($this->options['api_url']) ? $this->options['api_url'] : 'http://localhost:8080/api/orders/';
        if (empty($this->options['seller_id']) || empty($this->options['secret_key']) || empty($this->options['hmac_key'])) {
            $order->add_order_note(sprintf(__('Sync Failed: API credentials are not set in plugin settings.', 'fetchto')));
            return;
        }

        $products_payload = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product) continue;

            $category_list = wp_strip_all_tags(wc_get_product_category_list($product->get_id()));
            $categories = explode(',', $category_list);
            $primary_category = !empty($categories) ? trim($categories[0]) : 'Uncategorized';

            $products_payload[] = [
                'product_id' => (string)$product->get_id(),
                'skuId'      => $product->get_sku() ?: 'N/A',
                'category'   => $primary_category,
                'quantity'   => $item->get_quantity(),
                'price'      => (float)$product->get_price(),
                'name'       => $item->get_name(),
            ];
        }

        $address_parts = [$order->get_shipping_address_1(), $order->get_shipping_address_2(), $order->get_shipping_city(), $order->get_shipping_state(), $order->get_shipping_postcode()];
        $clean_address = implode(', ', array_filter($address_parts));

        $plaintext_data = [
            'products'        => $products_payload,
            'totalPrice'      => (float)$order->get_total(),
            'shippingAddress' => $clean_address,
            'phoneNumber'     => $order->get_billing_phone(),
            'buyerName'       => $order->get_formatted_billing_full_name(),
            'buyerEmail'      => $order->get_billing_email(),
            'woo_order_id'    => (string)$order_id, 
        ];

        $json_plaintext = json_encode($plaintext_data);

        try {
            $aes_key = base64_decode($this->options['secret_key']);
            $hmac_key = base64_decode($this->options['hmac_key']);
            
            $iv = openssl_random_pseudo_bytes(12);
            $tag = null;
            $ciphertext = openssl_encrypt($json_plaintext, 'aes-256-gcm', $aes_key, OPENSSL_RAW_DATA, $iv, $tag);
            
            if ($ciphertext === false || $tag === null) {
                throw new Exception('Encryption failed.');
            }

            $data_to_sign = base64_encode($iv) . base64_encode($ciphertext) . base64_encode($tag);
            $hmac_signature = hash_hmac('sha256', $data_to_sign, $hmac_key, true);

            $final_payload = [
                'iv'            => base64_encode($iv),
                'tag'           => base64_encode($tag),
                'ciphertext'    => base64_encode($ciphertext),
                'hmacSignature' => base64_encode($hmac_signature)
            ];

            $response = wp_remote_post($api_url . $this->options['seller_id'], [
                'method'  => 'POST',
                'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
                'body'    => json_encode($final_payload),
                'timeout' => 30
            ]);

            if (is_wp_error($response)) {
                $order->add_order_note(sprintf(__('Sync Error: %s', 'fetchto'), $response->get_error_message()));
            } else {
                $order->add_order_note(__('Order successfully synced with backend.', 'fetchto'));
            }

        } catch (Exception $e) {
            $order->add_order_note(sprintf(__('Encryption/Sync Failed: %s', 'fetchto'), $e->getMessage()));
        }
    }

    public function save_and_sync_all_updates($order_id) {
        $order = wc_get_order($order_id);
        
        if (isset($_POST['_fetchto_courier_name'])) {
            $order->update_meta_data('_fetchto_courier_name', sanitize_text_field($_POST['_fetchto_courier_name']));
        }
        if (isset($_POST['_fetchto_awb_number'])) {
            $order->update_meta_data('_fetchto_awb_number', sanitize_text_field($_POST['_fetchto_awb_number']));
        }
        $order->save();

        $new_status_from_form = isset($_POST['order_status']) ? sanitize_text_field($_POST['order_status']) : $order->get_status();
        
        $payload = [
            'id' => $order_id,
            'status' => str_replace('wc-', '', $new_status_from_form),
            'fetchto_data' => [
                'courier_name' => $order->get_meta('_fetchto_courier_name'),
                'awb_number'   => $order->get_meta('_fetchto_awb_number')
            ]
        ];
        
        $api_url = !empty($this->options['api_url']) ? $this->options['api_url'] : 'http://localhost:8080/api/webhook/woocommerce-update';
        wp_remote_post($api_url, [
            'method'  => 'POST',
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'body'    => json_encode($payload),
            'timeout' => 30
        ]);
    }

    public function add_custom_fields_to_admin_order($order) {
        echo '<div class="address_class">';
        woocommerce_wp_text_input(['id' => '_fetchto_courier_name', 'label' => __('Courier Name:', 'fetchto'), 'value' => $order->get_meta('_fetchto_courier_name'), 'wrapper_class' => 'form-field-wide']);
        woocommerce_wp_text_input(['id' => '_fetchto_awb_number', 'label' => __('AWB / Tracking Number:', 'fetchto'), 'value' => $order->get_meta('_fetchto_awb_number'), 'wrapper_class' => 'form-field-wide']);
        echo '</div>';
    }

    public function add_tracking_column_to_orders_list($columns) {
        $new_columns = [];
        foreach ($columns as $key => $name) {
            $new_columns[$key] = $name;
            if ('order-status' === $key) {
                $new_columns['fetchto-tracking'] = __('Tracking Info', 'fetchto');
            }
        }
        return $new_columns;
    }

    public function display_tracking_column_content($order) {
        $courier_name = $order->get_meta('_fetchto_courier_name');
        $awb_number = $order->get_meta('_fetchto_awb_number');

        if (!empty($courier_name) && !empty($awb_number)) {
            echo '<strong>' . esc_html($courier_name) . '</strong><br>';
            echo esc_html($awb_number);
        } else {
            echo __('N/A', 'fetchto');
        }
    }

    public function display_tracking_details_on_view_order_page($order_id) {
        $order = wc_get_order($order_id);
        $courier_name = $order->get_meta('_fetchto_courier_name');
        $awb_number = $order->get_meta('_fetchto_awb_number');
        $status = $order->get_status(); 

        if (!empty($courier_name) || !empty($awb_number)) {
            ?>
            <section class="woocommerce-customer-details">
                <h2 class="woocommerce-column__title"><?php _e('Shipment Tracking', 'fetchto'); ?></h2>
                <table class="woocommerce-table woocommerce-table--tracking-details shop_table tracking_details">
                    <tbody>
                        <tr>
                            <th><?php _e('Courier:', 'fetchto'); ?></th>
                            <td><?php echo esc_html($courier_name ?: __('Not yet assigned', 'fetchto')); ?></td>
                        </tr>
                        <tr>
                            <th><?php _e('Tracking Number (AWB):', 'fetchto'); ?></th>
                            <td><?php echo esc_html($awb_number ?: __('Not yet assigned', 'fetchto')); ?></td>
                        </tr>
                        <tr>
                            <th><?php _e('Status:', 'fetchto'); ?></th>
                            <td><?php echo esc_html(ucfirst(str_replace('wc-', '', $status))); ?></td> 
                        </tr>
                    </tbody>
                </table>
            </section>
            <?php
        }
    }

    public function register_callback_endpoint() {
        register_rest_route('fetchto/v1', '/update-awb', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_backend_update_callback'],
            'permission_callback' => '__return_true'
        ]);
    }

    public function handle_backend_update_callback($request) {
        $params = $request->get_json_params();
        $order_id = isset($params['orderId']) ? intval($params['orderId']) : 0;
        
        if ($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                if (isset($params['courierName'])) {
                    $order->update_meta_data('_fetchto_courier_name', sanitize_text_field($params['courierName']));
                }
                if (isset($params['trackingNumber'])) { 
                    $order->update_meta_data('_fetchto_awb_number', sanitize_text_field($params['trackingNumber']));
                }
                if (isset($params['status'])) {
                    $status = sanitize_text_field($params['status']);
                    $order->update_status($status); 
                    $order->add_order_note(sprintf(__('Order status updated to %s via webhook.', 'fetchto'), $status));
                }
                $order->save();
                return new WP_REST_Response(['message' => __('Order meta updated from backend.', 'fetchto')], 200);
            }
        }
        return new WP_REST_Response(['error' => __('Invalid data or order not found.', 'fetchto')], 400);
    }
}