=== Fetchto WooCommerce Integration Plugin ===

Contributors: prasannavenkatesh, Anand, Ravishankar
Tags: woocommerce, fetchto, order sync, logistics, e-commerce
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.5.0
License: MIT
License URI: https://fetchto.com/license

== Overview ==

The Fetchto WooCommerce Plugin seamlessly connects your WooCommerce store to the Fetchto logistics platform.
This plugin automates order synchronization, enables AWB (Air Waybill) generation, and streamlines delivery management directly from your Fetchto Seller Panel.

Important: Your Seller Credentials (Seller ID, HMAC, Secret Key) are confidential. Do not share them or use them in any third-party applications.

== Description ==

The Fetchto WooCommerce Integration Plugin connects your WooCommerce store to the Fetchto logistics platform. Automate order synchronization, generate AWBs, and manage deliveries directly from your Fetchto Seller Panel.

== Company Information ==

Company Name: Fetchto Technologies Pvt Ltd  
Website: https://fetchto.com  
Support Email: support@fetchto.com  

== Prerequisites ==

Before installation, ensure you have:

* A valid Fetchto Seller Account
* Seller Credentials (Seller ID, HMAC, Secret Key) — available in your Fetchto Dashboard
* An active WooCommerce store

== Installation Guide ==

=== Option 1: Install from WordPress Plugin Directory ===
1. In your WordPress Admin Panel, go to: Plugins → Add New
2. Search for Fetchto WooCommerce Plugin.
3. Click Install Now and then Activate.
4. Refresh your WordPress admin dashboard.

=== Option 2: Manual Installation ===
1. Download the Fetchto WooCommerce Plugin package from our official website.
2. In your WordPress Admin Panel, go to: Plugins → Add New → Upload Plugin
3. Upload the .zip file, click Install Now, and then Activate.
4. Refresh your WordPress admin dashboard.

=== Step 2: Configure Seller Credentials ===
1. In your WordPress Admin Panel, go to: Settings → Fetchto
2. Enter the following credentials (from Fetchto Dashboard):
   * Seller ID
   * HMAC
   * Secret Key
3. Click Save.
4. Refresh the page to ensure credentials are saved successfully.

Refer image: after install.png, add your seller_credentials.png

=== Step 3: Setup WooCommerce Webhook ===
1. Go to: WooCommerce → Settings → Advanced → Webhooks
2. Click Add Webhook and configure:

| Field            | Value                                                                                   |
| ---------------- | --------------------------------------------------------------------------------------- |
| Name             | Fetchto                                                                                 |
| Status           | Active                                                                                  |
| Topic            | Order Update                                                                            |
| Delivery URL     | http://localhost/wordpress/wp-json/fetchto/v1/update-awb (replace with live site URL)   |
| Secret           | (Leave Empty)                                                                           |
| API Version      | WP REST API v3                                                                          |

3. Click Save Webhook.

Refer images: go_to_setting.png, click advanced.png, add webhook.png

=== Step 4: Verify Integration ===
* Refresh WooCommerce.
* Place a test order.
* The order should now sync automatically into your Fetchto Seller Panel for fulfillment.

== Troubleshooting ==

* Orders not syncing? → Ensure Webhook is Active and Delivery URL is correct.
* Invalid Credentials? → Double-check Seller ID, HMAC, and Secret Key.
* No data in Fetchto? → Refresh Fetchto Dashboard after placing a WooCommerce order.

== Security Notes ==

* Your Seller ID, HMAC, and Secret Key must remain confidential.
* Do NOT share credentials outside of the Fetchto WooCommerce Plugin.
* Do NOT add credentials to third-party applications or unauthorized platforms.

== Support ==

For assistance, contact us at:  
support@fetchto.com  
https://fetchto.com/help  

== License ==

This plugin is licensed under the MIT License. See the LICENSE file for details.

== Final Note ==

With this plugin, all WooCommerce order updates will automatically flow into your Fetchto logistics panel, ensuring fast and reliable order fulfillment.
