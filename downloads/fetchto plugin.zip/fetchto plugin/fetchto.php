<?php
/**
 * Plugin Name:       Fetchto
 * Plugin URI:        https://example.com/plugin
 * Description:       Syncs WooCommerce orders with a backend via a direct webhook for automated order fulfillment.
 * Version:           1.5.0
 * Author:            Prasanna Venkatesh K
 * Author URI:        https://example.com
 * License:           MIT
 * License URI:       https://example.com/license
 * Text Domain:       fetchto
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Tested up to:      6.6
 * WC requires at least: 5.0
 * WC tested up to:   9.0
 */

if (!defined('ABSPATH')) exit; 

require_once plugin_dir_path(__FILE__) . 'includes/class-fetchto.php';

function run_fetchto() {
    new Fetchto();
}
add_action('plugins_loaded', 'run_fetchto');

add_action('init', 'register_shipped_order_status');
function register_shipped_order_status() {
    register_post_status('wc-shipped', [
        'label'                     => 'Shipped',
        'public'                    => true,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop('Shipped <span class="count">(%s)</span>', 'Shipped <span class="count">(%s)</span>')
    ]);
}

add_filter('wc_order_statuses', 'add_shipped_to_order_statuses');
function add_shipped_to_order_statuses($order_statuses) {
    $new_order_statuses = [];
    foreach ($order_statuses as $key => $status) {
        $new_order_statuses[$key] = $status;
        if ('wc-processing' === $key) {
            $new_order_statuses['wc-shipped'] = 'Shipped';
        }
    }
    return $new_order_statuses;
}